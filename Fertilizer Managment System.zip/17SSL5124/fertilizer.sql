-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 03, 2023 at 11:25 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fertilizer`
--

-- --------------------------------------------------------

--
-- Table structure for table `farmers`
--

DROP TABLE IF EXISTS `farmers`;
CREATE TABLE IF NOT EXISTS `farmers` (
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `NIC` varchar(12) NOT NULL,
  `Phone` int(10) NOT NULL,
  `Acrage` double NOT NULL,
  `Crop_Type` varchar(50) NOT NULL,
  `Fertilizer_1` varchar(50) NOT NULL,
  `Amount_F1` double NOT NULL,
  `Fertilizer_2` varchar(50) NOT NULL,
  `Amount_F2` double NOT NULL,
  `Fertilizer_3` varchar(50) NOT NULL,
  `Amount_F3` double NOT NULL,
  PRIMARY KEY (`NIC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `farmers`
--

INSERT INTO `farmers` (`First_Name`, `Last_Name`, `NIC`, `Phone`, `Acrage`, `Crop_Type`, `Fertilizer_1`, `Amount_F1`, `Fertilizer_2`, `Amount_F2`, `Fertilizer_3`, `Amount_F3`) VALUES
('indu', 'madumika', '9664710266v', 712098652, 8, 'paddy', 'Urea', 2, 'MOP', 2, 'TSP', 5),
(' Niroshi', 'Kaushalya', '1998056534v', 712069835, 2.5, 'paddy', 'Urea', 2, 'MOP', 5, 'TSP', 3),
('Aruni', 'Jayarathne', '1998326548V', 765812358, 8, 'paddy', 'MOP', 2, 'Urea', 3, 'TSP', 5),
('niroma', 'samadi', '1998745932v', 758946538, 5, 'corn', 'Urea', 2, '2.0', 2, 'Urea', 2),
('malindu', 'kamal', '986520203V', 762065390, 2, 'corn', 'Urea', 2, 'MOP', 1, 'TSP', 1),
('abc', 'abc', '19986520233V', 712065931, 5, 'paddy', 'Urea', 0, 'Urea', 0, 'Urea', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fertilizer_details`
--

DROP TABLE IF EXISTS `fertilizer_details`;
CREATE TABLE IF NOT EXISTS `fertilizer_details` (
  `F_id` int(11) NOT NULL AUTO_INCREMENT,
  `Fert_name` varchar(50) NOT NULL,
  PRIMARY KEY (`F_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fertilizer_details`
--

INSERT INTO `fertilizer_details` (`F_id`, `Fert_name`) VALUES
(1, 'Urea'),
(2, 'MOP'),
(3, 'TSP');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `User_name` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `User_name`, `password`) VALUES
(7, 'sithmi', '$2a$12$iAK8nT/8anvEMzZAa8nRVez1If4//vA18XOtoMGBoxeSGzoHBXj8K'),
(8, 'admin', '$2a$12$OlJ4Nk1VHgXetvCUDNcZaeigxKtGz1hMbE8qvYnJT59Ogt/EspG2W'),
(9, 'abc', '$2a$12$2GrBb8lqVHGTsuANamV1FeXOaTDFRacaAopIVRSCdwDB135ZrIs/6'),
(10, 'abc', '$2a$12$pcIU.3ECdOxENzcD84R7..HUXNGdrqavynyUvhE7Myu0HFxdsnitW');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
