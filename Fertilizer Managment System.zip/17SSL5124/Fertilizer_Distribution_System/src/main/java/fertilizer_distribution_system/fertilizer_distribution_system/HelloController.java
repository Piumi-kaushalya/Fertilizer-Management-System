package fertilizer_distribution_system.fertilizer_distribution_system;


import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class HelloController {
    @FXML
    private TableColumn<?, String> s_id;

    @FXML
    private TableColumn<?, String> s_name;

    @FXML
    private TableView<?> tbl1;

    public  void stuData(){

    }
}