package fertilizer_distribution_system.fertilizer_distribution_system;
import Model.AdminModel;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.event.EventType;

import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {
    @FXML
    private Button Btncancel;

    @FXML
    private Button Btnsing;

    @FXML
    private Label Lblerrormsg;

    @FXML
    private Label Lblerrorpass;

    @FXML
    private TextField Txtpw;

    @FXML
    private TextField Txtuname;

    @FXML
    void Btnclose(ActionEvent event) {

    }

    @FXML
    void Btnlogin(ActionEvent event) throws Exception {
        String username, password;
        username = Txtuname.getText();
        password = Txtpw.getText();
        Lblerrormsg.setText("");

        if (ValidationRules.isEmpty(username) || ValidationRules.isEmpty(password)) {
            Lblerrormsg.setText("Please enter Username & Password");
        } else {
            AdminModel adminModel = new AdminModel();
            boolean result = adminModel.login(username, password);
            if (result) {
                System.out.println("Login success");
                Txtuname.clear();
                Txtpw.clear();
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Dashboard.fxml"));
                Scene scene = new Scene(fxmlLoader.load());
                Stage dashboard = new Stage();
                dashboard.setTitle("Dashboard");
                dashboard.setScene(scene);
                dashboard.show();
                closeLoginWindow();
            }
            else {
                Lblerrormsg.setText("Incorrect Username or Password");
            }
        }



    }

    private void closeLoginWindow() {
        Stage stage = (Stage) Btnsing.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
//        Txtuname.setOnKeyPressed(keyEvent -> Lblerrormsg.setText(""));
//
//        Txtpw.setOnKeyPressed(new EventHandler<KeyEvent>() {
//            @Override
//            public void handle(KeyEvent keyEvent) {
//                Lblerrormsg.setText("");
//            }
       // });
    }
}
