package fertilizer_distribution_system.fertilizer_distribution_system;
public class Login {
}
////import javafx.application.Application;
////import javafx.event.ActionEvent;
////import javafx.event.EventHandler;
////import javafx.fxml.FXML;
////import javafx.fxml.FXMLLoader;
////import javafx.fxml.Initializable;
////import javafx.scene.Parent;
////import javafx.scene.Scene;
////import javafx.scene.control.Button;
////import javafx.scene.control.Label;
////import javafx.scene.control.TextField;
////import javafx.scene.input.MouseEvent;
////import javafx.stage.Stage;
////
////import java.io.IOException;
////import java.net.URL;
////import java.util.ResourceBundle;
//
//
//public class Login implements Initializable {
//    @FXML
//    private Button Btncancel;
//
//    @FXML
//    private Button Btnsing;
//
//    @FXML
//    private Label Lblerrormsg;
//
//    @FXML
//    private Label Lblerrorpass;
//
//    @FXML
//    private TextField Txtpw;
//
//    @FXML
//    private TextField Txtuname;
//
//
//    @FXML
//    void Btnlogin(ActionEvent event) {
//
//    }
//    @FXML
//    void Btnclose(ActionEvent event) {
//
//    }
//    private String errorMessage ="";
//    private boolean isFieldFilled() {
//        boolean isFielled = true;
//        if (Txtuname.getText().isEmpty()) {
//            isFielled = false;
//            errorMessage = "Username is Empty!";
//        }
//        if (Txtpw.getText().isEmpty()) {
//            isFielled = false;
//            if (errorMessage.isEmpty()) {
//                errorMessage = "Password is Empty!";
//            } else {
//                errorMessage += "\nPassword is Empty!";
//            }
//        }
//        Lblerrormsg.setText(errorMessage);
//        return isFielled;
//    }
//    private boolean isValid(){
//        boolean isValid =true;
//        if(!Txtuname.getText().equals(HelloApplication.USERNAME)){
//            isValid = false;
//            errorMessage="Invalide UserName!";
//        }
//        if(!Txtpw.getText().equals(HelloApplication.PASSWORD)){
//            isValid=false;
//            if(errorMessage.isEmpty()) {
//                errorMessage = "Invalide Password!";
//            }else {
//                errorMessage += "\nInvalide Password!";
//            }
//        }
//        Lblerrorpass.setText(errorMessage);
//        return isValid;
//    }
//    private void statHomeWindow(){
//        try {
//            Parent root =
//                    FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
//            Stage stage =new Stage();
//            stage.setMaximized(true);
//            stage.setScene(new Scene(root));
//            stage.show();
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//    }
//
//
//    @Override
//    public void initialize(URL url, ResourceBundle resourceBundle) {
//        Btncancel.setOnMouseClicked(new EventHandler<MouseEvent>() {
//        public void handle(MouseEvent mouseEvent) {
//                System.exit(0);
//            }
//        });
//        Btnsing.setOnMouseClicked(new EventHandler<MouseEvent>() {
//            @Override
//            public void handle(MouseEvent mouseEvent) {
//                errorMessage ="";
//                if(isFieldFilled() &&isValid()){
//                    statHomeWindow();
//                }
//            }
//        });
//    }
//
//
//    }

