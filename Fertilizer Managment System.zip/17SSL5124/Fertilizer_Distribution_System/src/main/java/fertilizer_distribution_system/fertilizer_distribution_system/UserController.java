package fertilizer_distribution_system.fertilizer_distribution_system;
import Model.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;


public class UserController implements Initializable {
    @FXML
    private ComboBox Cmb3;

    @FXML
    private ComboBox Cmbf1;

    @FXML
    private ComboBox Cmbf2;
    @FXML
    private Label Lblerror;

    @FXML
    private Label Lblerroracrage;

    @FXML
    private Label Lblerrorcrop;

    @FXML
    private Label Lblerrorfname;

    @FXML
    private Label Lblerrorlname;

    @FXML
    private Label Lblerrornic;

    @FXML
    private Label Lblerrorphone;

    @FXML
    private Label Lblsuccess;

    @FXML
    private AnchorPane Reg_pane;

    @FXML
    private Button btncancel;

    @FXML
    private Button btninsert;

    @FXML
    private Button btnview;

    @FXML
    private TextField txtacrage;

    @FXML
    private TextField txtamount1;

    @FXML
    private TextField txtamount2;

    @FXML
    private TextField txtamount3;

    @FXML
    private TextField txtcrop;

    @FXML
    private TextField txtfname;

    @FXML
    private TextField txtlname;

    @FXML
    private TextField txtnic;

    @FXML
    private TextField txtphone;

//    @FXML
//    void BtnInsert(ActionEvent event) {
//
//    }

    @FXML
    void Btncancel(ActionEvent event) {
        Stage stage = (Stage) btncancel.getScene().getWindow();
        stage.close();

    }

    @FXML
    void Btnview(ActionEvent event) {

    }

public void BtnInsert(ActionEvent ex){
    Lblerror.setText("");
    Lblsuccess.setText("");
    Lblerrorfname.setText("");
    Lblerrorlname.setText("");
    Lblerrornic.setText("");
    Lblerrorphone.setText("");
    Lblerroracrage.setText("");
    Lblerrorcrop.setText("");

    txtfname.getStyleClass().remove("errors");
    txtlname.getStyleClass().remove("errors");
    txtnic.getStyleClass().remove("errors");
    txtphone.getStyleClass().remove("errors");
    txtacrage.getStyleClass().remove("errors");
    txtcrop.getStyleClass().remove("errors");
    txtamount1.getStyleClass().remove("errors");
    txtamount2.getStyleClass().remove("errors");
    txtamount3.getStyleClass().remove("errors");

    String fname = txtfname.getText();
    String lname=txtlname.getText();
    String nic=txtnic.getText();
    String phone=txtphone.getText();
    String acrage=txtacrage.getText();
    String crop = txtcrop.getText();
    String f1 = (String) Cmbf1.getSelectionModel().getSelectedItem();
    String amount1 = txtamount1.getText();
    String f2 = (String) Cmbf2.getSelectionModel().getSelectedItem();
    String amount2 = txtamount2.getText();
    String f3 = (String) Cmb3.getSelectionModel().getSelectedItem();
    String amount3 = txtamount3.getText();
    //System.out.println(f1);
    ArrayList<Integer> errors = new ArrayList<Integer>();
    //
    if (ValidationRules.isEmpty(fname) || ValidationRules.isEmpty(lname) ||
            ValidationRules.isEmpty(nic) || ValidationRules.isEmpty(phone) ||
            ValidationRules.isEmpty(acrage) || ValidationRules.isEmpty(crop) ||
         ValidationRules.isEmpty(f1) || ValidationRules.isEmpty(amount1) ||
            ValidationRules.isEmpty(f2) || ValidationRules.isEmpty(amount2) ||
            ValidationRules.isEmpty(f3) || ValidationRules.isEmpty(amount3)
    ) {
        errors.add(1);
        Lblerror.setText("All fields are required");
    }else {

//
        if (!ValidationRules.isText(fname)) {
            errors.add(1);
            Lblerrorfname.setText("Invalid first name");
            txtfname.getStyleClass().add("errors");
        }


        if (!ValidationRules.isText(lname)) {
            errors.add(1);
            Lblerrorlname.setText("Invalid last name");
            txtlname.getStyleClass().add("errors");
        }
        if (!ValidationRules.validateNIC(nic)) {
            errors.add(1);
            Lblerrorlname.setText("Invalid nic");
            txtlname.getStyleClass().add("errors");
        }



        if  (!ValidationRules.isMobile(phone)) {
            errors.add(1);
            Lblerrorphone.setText("Enter valied number");
            txtphone.getStyleClass().add("errors");
        }
        else {
            boolean result = UserModel.BtnInsert(fname, lname, nic, phone, acrage, crop,f1,amount1,f2,amount2,f3,amount3);
            if (result) {
                Lblsuccess.setText("New detail added.");
                //
                txtfname.clear();
                txtlname.clear();
                txtnic.clear();
                txtphone.clear();
                txtacrage.clear();
                txtcrop.clear();
                txtamount1.clear();
                txtamount2.clear();
                txtamount3.clear();



            }}}}



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UsertypesModel usertypesModel = new UsertypesModel();
        ResultSet rs = usertypesModel.getTypes();
        try {
            while (rs.next()) {
                //System.out.println(rs.getString("Fert_name"));
                Cmbf1.getItems().add(rs.getString("Fert_name"));
            }
        } catch (SQLException ex) {
            //System.out.println(ex.getMessage());
            throw new RuntimeException(ex);
        }

        CropModel cropModel = new CropModel();
        ResultSet res = cropModel.getCrops();
        try {
            while (res.next()) {
                //System.out.println(rs.getString("Fert_name"));
                Cmbf2.getItems().add(res.getString("Fert_name"));
            }
        } catch (SQLException ex) {
            //System.out.println(ex.getMessage());
            throw new RuntimeException(ex);
        }
       ThirdModel thirdModel = new ThirdModel();
        ResultSet rslt = thirdModel.getFerts();
        try {
            while (rslt.next()) {
                //System.out.println(rs.getString("Fert_name"));
                Cmb3.getItems().add(rslt.getString("Fert_name"));
            }
        } catch (SQLException ex) {
            //System.out.println(ex.getMessage());
            throw new RuntimeException(ex);
        }



    }}




