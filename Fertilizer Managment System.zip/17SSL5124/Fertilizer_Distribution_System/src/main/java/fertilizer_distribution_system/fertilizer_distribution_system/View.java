package fertilizer_distribution_system.fertilizer_distribution_system;

public class View {
    public String First_Name,Last_Name,NIC,Phone,Acrage,Crop_Type,Fertilizer_1,Amount_F1,Fertilizer_2,Amount_F2,Fertilizer_3,Amount_F3;

    public String getFirst_Name() {
        return First_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public String getNIC() {
        return NIC;
    }

    public String getPhone() {
        return Phone;
    }

    public String getAcrage() {
        return Acrage;
    }

    public String getCrop_Type() {
        return Crop_Type;
    }

    public String getFertilizer_1() {
        return Fertilizer_1;
    }

    public String getAmount_F1() {
        return Amount_F1;
    }

    public String getFertilizer_2() {
        return Fertilizer_2;
    }

    public String getAmount_F2() {
        return Amount_F2;
    }

    public String getFertilizer_3() {
        return Fertilizer_3;
    }

    public String getAmount_F3() {
        return Amount_F3;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public void setLast_Name(String last_Name) {
        Last_Name = last_Name;
    }

    public void setNIC(String NIC) {
        this.NIC = NIC;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public void setAcrage(String acrage) {
        Acrage = acrage;
    }

    public void setCrop_Type(String crop_Type) {
        Crop_Type = crop_Type;
    }

    public void setFertilizer_1(String fertilizer_1) {
        Fertilizer_1 = fertilizer_1;
    }

    public void setAmount_F1(String amount_F1) {
        Amount_F1 = amount_F1;
    }

    public void setFertilizer_2(String fertilizer_2) {
        Fertilizer_2 = fertilizer_2;
    }

    public void setAmount_F2(String amount_F2) {
        Amount_F2 = amount_F2;
    }

    public void setFertilizer_3(String fertilizer_3) {
        Fertilizer_3 = fertilizer_3;
    }

    public void setAmount_F3(String amount_F3) {
        Amount_F3 = amount_F3;
    }

    public View(String first_Name, String last_Name, String NIC, String phone, String acrage, String crop_Type, String fertilizer_1, String amount_F1, String fertilizer_2, String amount_F2, String fertilizer_3, String amount_F3) {
        First_Name = first_Name;
        Last_Name = last_Name;
        this.NIC = NIC;
        Phone = phone;
        Acrage = acrage;
        Crop_Type = crop_Type;
        Fertilizer_1 = fertilizer_1;
        Amount_F1 = amount_F1;
        Fertilizer_2 = fertilizer_2;
        Amount_F2 = amount_F2;
        Fertilizer_3 = fertilizer_3;
        Amount_F3 = amount_F3;
    }
}

