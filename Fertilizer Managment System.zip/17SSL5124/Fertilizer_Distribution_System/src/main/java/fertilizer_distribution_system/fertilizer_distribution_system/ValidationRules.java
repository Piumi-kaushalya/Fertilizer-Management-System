package fertilizer_distribution_system.fertilizer_distribution_system;

public class ValidationRules {
    public static boolean isEmpty(String val) {
        return (val == null || val.isEmpty() || val.isBlank());
    }

    public static boolean minLen(String val, Integer len) {
        isEmpty(val);
        return val.length() >= len;

    }

    public static boolean isMobile(String phone) {
        isEmpty(phone);
        return phone.matches("\\d{10}") && phone.length() == 10;
        // if (phone.matches("\\d{10}"))
        //return val.matches("\\d{8}|\\d{11}");
        // if (phone.matches("\\d{2}|\\d{11}"))
        //return phone.length() == 10;
//


        //return false;
    }

    public static boolean isText(String val) {
        isEmpty(val);
        return val.matches("[a-zA-Z ]+");
    }
    public  static boolean isEmail(String val){

        return val.matches("[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}");
    }
    public static boolean validateNIC(String nic) {
        // Check if length is 10
        int length = nic.length();
        if (length != 10) {
            return false;
        }

        // Check last character for v, V, x, or X
        char lastChar = nic.charAt(length - 1);
        if (lastChar != 'v' || lastChar != 'V' ){
                //||
                //lastChar != 'x' || lastChar != 'X') {
            return false;
        }

        // Check first 9 characters are digits
        for (int i = 0; i < length - 2; i++) {
            char currentChar = nic.charAt(i);
            if (currentChar < '0' || '9' < currentChar) {
                return false;
            }
        }

        return true;
    }



}




//    public static Boolean isEmpty(String val){
//        val = val.trim();
//        return val.isBlank();}
//
//        public static Boolean minLen(String val,Integer len){
//            isEmpty(val);
//            return val.length() >= len;


    // }



