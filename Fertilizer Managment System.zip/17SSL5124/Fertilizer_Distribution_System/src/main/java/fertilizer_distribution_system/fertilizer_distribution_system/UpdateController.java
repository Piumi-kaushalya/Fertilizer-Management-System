package fertilizer_distribution_system.fertilizer_distribution_system;
import Model.UpdateModel;
import Model.View_Model;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
//import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;


public class UpdateController implements Initializable {
    @FXML
    private Button Btnupdate;

    @FXML
    private TableView<View> Tblview;

    @FXML
    private TextField inputf1;

    @FXML
    private TextField inputf2;

    @FXML
    private TextField inputf3;


    @FXML
    private TableColumn<View, String> colacrage;

    @FXML
    private TableColumn<View, String> colamt1;

    @FXML
    private TableColumn<View, String> colamt2;

    @FXML
    private TableColumn<View, String> colamt3;

    @FXML
    private TableColumn<View, String> colcroptype;

    @FXML
    private TableColumn<View, String> colf1;

    @FXML
    private TableColumn<View, String> colf2;

    @FXML
    private TableColumn<View, String> colf3;

    @FXML
    private TableColumn<View, String> colfname;

    @FXML
    private TableColumn<View, String> collname;

    @FXML
    private TableColumn<View, String> colnic;

    @FXML
    private TableColumn<View, String> colphone;

    @FXML
    private TextField inpunic;

    @FXML
    private TextField inputacrage;

    @FXML
    private TextField inputamt1;

    @FXML
    private TextField inputamt2;

    @FXML
    private TextField inputamt3;

    @FXML
    private TextField inputcroptype;

    @FXML
    private TextField inputfname;

    @FXML
    private TextField inputlname;

    @FXML
    private TextField inputphone;

    @FXML
    void btncancel(ActionEvent event) {

    }





    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        View_Model view_model= new View_Model();
        colfname.setCellValueFactory(new PropertyValueFactory<View, String>("First_Name"));
        collname.setCellValueFactory(new PropertyValueFactory<View, String>("Last_Name"));
        colnic.setCellValueFactory(new PropertyValueFactory<View, String>("NIC"));
        colphone.setCellValueFactory(new PropertyValueFactory<View, String>("Phone"));
        colacrage.setCellValueFactory(new PropertyValueFactory<View, String>("Acrage"));
        colcroptype.setCellValueFactory(new PropertyValueFactory<View, String>("Crop_Type"));
        colf1.setCellValueFactory(new PropertyValueFactory<View, String>("Fertilizer_1"));
       colamt1.setCellValueFactory(new PropertyValueFactory<View, String>("Amount_F1"));
        colf2.setCellValueFactory(new PropertyValueFactory<View, String>("Fertilizer_2"));
        colamt2.setCellValueFactory(new PropertyValueFactory<View, String>("Amount_F2"));
        colf3.setCellValueFactory(new PropertyValueFactory<View, String>("Fertilizer_3"));
        colamt3.setCellValueFactory(new PropertyValueFactory<View, String>("Amount_F3"));


        Tblview.setItems(view_model.getUser());

    }
    @FXML
    void btnupdate(ActionEvent event) {

        ObservableList<View> currentTabledata = Tblview.getItems();
        String currentnic = (inpunic.getText());
        for (View view : currentTabledata) {

            view.setFirst_Name(inputfname.getText());
            view.setLast_Name(inputlname.getText());
            view.setNIC(inpunic.getText());
            view.setPhone(inputphone.getText());
            view.setAcrage(inputacrage.getText());
            view.setCrop_Type(inputcroptype.getText());
            view.setFertilizer_1(inputf1.getText());
            view.setAmount_F1(inputamt1.getText());
            view.setFertilizer_2(inputf2.getText());
            view.setAmount_F2(inputamt2.getText());
            view.setFertilizer_3(inputf3.getText());
            view.setAmount_F3(inputamt3.getText());
            Tblview.setItems(currentTabledata);
            Tblview.refresh();
            String fname = inputfname.getText();
            String lname = inputlname.getText();
            String nic = inpunic.getText();
            String phone = inputphone.getText();
            String acrage = inputacrage.getText();
            String croptype = inputcroptype.getText();
            String f1 = inputf1.getText();
            String famt1 = inputamt1.getText();
            String f2 = inputamt2.getText();
            String famt2 = inputamt2.getText();
            String f3 = inputf1.getText();
            String famt3 = inputamt3.getText();
            UpdateModel updateModel = new UpdateModel();
            boolean result = updateModel.Updateuser(fname,lname,nic,phone,acrage,croptype,f1,famt1,f2,famt2,f3,famt3);
            break;
        }
        }
    @FXML
    void rowClicked(MouseEvent event) {
        View clickedView = Tblview.getSelectionModel().getSelectedItem();
        inputfname.setText(String.valueOf(clickedView.getFirst_Name()));
        inputlname.setText(String.valueOf(clickedView.getLast_Name()));
        inpunic.setText(String.valueOf(clickedView.getNIC()));
        inputphone.setText(String.valueOf(clickedView.getPhone()));
        inputacrage.setText(String.valueOf(clickedView.getAcrage()));
        inputcroptype.setText(String.valueOf(clickedView.getCrop_Type()));
        inputf1.setText(String.valueOf(clickedView.getFertilizer_1()));
        inputamt1.setText(String.valueOf(clickedView.getAmount_F1()));
        inputf2.setText(String.valueOf(clickedView.getFertilizer_2()));
        inputamt2.setText(String.valueOf(clickedView.getAmount_F2()));
        inputf3.setText(String.valueOf(clickedView.getAmount_F2()));
        inputamt3.setText(String.valueOf(clickedView.getAmount_F3()));


    }

    }

