package fertilizer_distribution_system.fertilizer_distribution_system;
import Model.AdminModel;
import Model.UserModel;
import at.favre.lib.crypto.bcrypt.BCrypt;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.ArrayList;


public class AdminController {
    @FXML
    private Label Lblerrorpw;

    @FXML
    private Label Lblerroruname;

    @FXML
    private Label Lblsuccess;

    @FXML
    private Button btnregister;
    @FXML
    private TextField txtpw;

    @FXML
    private TextField txtuname;
    @FXML
    private Label Lblerror;


    @FXML
    void BtnUser(ActionEvent event) {
        Lblerroruname.setText("");
        Lblsuccess.setText("");
        Lblerrorpw.setText("");
        Lblerror.setText("");

        txtuname.getStyleClass().remove("errors");
        txtpw.getStyleClass().remove("errors");
        String username = txtuname.getText();
        String password = txtpw.getText();

        String hashedpassword = BCrypt.withDefaults().hashToString(12,password.toCharArray());
        ArrayList<Integer> erros = new ArrayList<Integer>();
        if (ValidationRules.isEmpty(username) || ValidationRules.isEmpty(password))
        {
            erros.add(1);
            Lblerror.setText("all fields are requierd");
        }
        else{
            if (!ValidationRules.isText(username)) {
                erros.add(1);
                Lblerroruname.setText(("invalied user name"));
                txtuname.getStyleClass().add("errors");
            }
            if (!ValidationRules.minLen(password,5)) {
                erros.add(1);
                Lblerrorpw.setText("password must hava at least 5 characters");
                txtpw.getStyleClass().add("errors");
            } else {
                boolean result = AdminModel.BtnUser(username, hashedpassword);
                if (result) {
                    Lblsuccess.setText("user added");
                    txtuname.clear();
                    txtpw.clear();


                }
            }
        }}}









