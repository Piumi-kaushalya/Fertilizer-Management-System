package fertilizer_distribution_system.fertilizer_distribution_system;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
//import javafx.stage.StageStyle;
import java.io.IOException;

public class HelloApplication extends Application {
    //public static final String USERNAME ="Admin";
    //public static final String PASSWORD ="123";
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Login_view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("System Login");
        stage.setScene(scene);
        stage.setMaximized(false);
        stage.show();
      //Parent root =FXMLLoader.load(getClass().getResource("Login_view.fxml"));
       //Primarystage.initStyle(StageStyle.UNDECORATED);
//        Primarystage.setScene(new Scene(root));
//        //Primarystage.setMaximized(false);
//        Primarystage.show();

    }

    public static void main(String[] args) {
        launch();
    }
}