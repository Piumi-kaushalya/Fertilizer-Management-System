package fertilizer_distribution_system.fertilizer_distribution_system;
import Model.UserModel;
import Model.View_Model;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class ViewController implements Initializable {
    @FXML
    private TableColumn<View, String> Acrage;

    @FXML
    private TableColumn<View, String> Amount_F1;

    @FXML
    private TableColumn<View, String> Amount_F2;

    @FXML
    private TableColumn<View, String> Amount_F3;

    @FXML
    private TableColumn<View, String> Crop_Type;

    @FXML
    private TableColumn<View, String> Fertilizer_1;

    @FXML
    private TableColumn<View, String> Fertilizer_2;

    @FXML
    private TableColumn<View, String> Fertilizer_3;

    @FXML
    private TableColumn<View, String> First_Name;

    @FXML
    private TableColumn<View, String> Last_Name;

    @FXML
    private TableColumn<View, String> NIC;

    @FXML
    private TableColumn<View, String> Phone;
    @FXML
    private Button btndelete;

    @FXML
    private Button btnsearch;

    @FXML
    private TableView<View> tbldetails;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.stuData();


    }
    public void stuData(){
        UserModel viewModel = new UserModel();
        First_Name.setCellValueFactory(new PropertyValueFactory<View, String>("First_Name"));
        Last_Name.setCellValueFactory(new PropertyValueFactory<View, String>("Last_Name"));
        NIC.setCellValueFactory(new PropertyValueFactory<View, String>("NIC"));
        Phone.setCellValueFactory(new PropertyValueFactory<View, String>("Phone"));
        Acrage.setCellValueFactory(new PropertyValueFactory<View, String>("Acrage"));
        Crop_Type.setCellValueFactory(new PropertyValueFactory<View, String>("Crop_Type"));
        Fertilizer_1.setCellValueFactory(new PropertyValueFactory<View, String>("Fertilizer_1"));
        Amount_F1.setCellValueFactory(new PropertyValueFactory<View, String>("Amount_F1"));
        Fertilizer_2.setCellValueFactory(new PropertyValueFactory<View, String>("Fertilizer_2"));
        Amount_F2.setCellValueFactory(new PropertyValueFactory<View, String>("Amount_F2"));
        Fertilizer_3.setCellValueFactory(new PropertyValueFactory<View, String>("Fertilizer_3"));
        Amount_F3.setCellValueFactory(new PropertyValueFactory<View, String>("Amount_F3"));

        View_Model view_model = new View_Model();
        tbldetails.setItems(view_model.getUser());
    }
    @FXML
    public void Delstu(ActionEvent event) {
        String NIC = tbldetails.getSelectionModel().getSelectedItem().NIC;
        View_Model view_model = new View_Model();
        Boolean result = view_model.delStudent(NIC);

        tbldetails.setItems(null);
        tbldetails.setItems(view_model.getUser());

        System.out.println(result);


    }

}
