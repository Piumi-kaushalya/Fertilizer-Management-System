package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CropModel {
    public static Connection Conn = Db.getConn();
    //private preparedstatement statement
    private static ResultSet res;
    public  ResultSet getCrops(){
        String sql = "SELECT * FROM fertilizer_details";

        try {
            PreparedStatement statement = Conn.prepareStatement(sql);
            res = statement.executeQuery();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return res;

    }
}
