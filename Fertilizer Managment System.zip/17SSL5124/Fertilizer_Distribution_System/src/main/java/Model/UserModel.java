package Model;

import fertilizer_distribution_system.fertilizer_distribution_system.View;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserModel {
    private static Connection connection = Db.getConn();
    private PreparedStatement stat;
    private ResultSet rs;

    public static boolean BtnInsert(String fname, String lname, String nic, String phone, String acrage, String crop, String f1, String amount1, String f2, String amount2, String f3, String amount3) {
        boolean result = false;
        String sql = "INSERT INTO farmers(First_Name, Last_Name, NIC, Phone, Acrage, Crop_Type, Fertilizer_1, Amount_F1, Fertilizer_2, Amount_F2, Fertilizer_3, Amount_F3) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ";
        try {
            PreparedStatement stat;
            stat = connection.prepareStatement(sql);
            //stat.setString(1,user_id);
            stat.setString(1, fname);


            //stat.setString();
            stat.setString(2, lname);
            stat.setString(3, nic);
            stat.setString(4, phone);
            stat.setString(5, acrage);
            stat.setString(6, crop);
            stat.setString(7, f1);
            stat.setString(8, amount1);
            stat.setString(9, f2);
            stat.setString(10, amount2);
            stat.setString(11, f3);
            stat.setString(12, amount3);
            result = stat.executeUpdate() == 1;
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }
        return result;
    }
//sample
   public static ObservableList<View> BtnInsert() {
      return BtnInsert();
   }}
//}
//    public static ObservableList<View> getUser(){
//       Connection Conn = Db.getConn();
//       ObservableList<View> list = FXCollections.observableArrayList();
//       String sql = "SELECT * FROM farmers";
//        try {
//           PreparedStatement stmt;
//        stmt = Conn.prepareStatement(sql);
//        ResultSet rs = stmt.executeQuery();
//          while (rs.next()){
//              String First_Name = rs.getString("First_Name");
//               String Last_Name = rs.getString("Last_Name");
//                String NIC = rs.getString("NIC");
//                String Phone = rs.getString("Phone");
//                String Acrage = rs.getString("Acrage");
//              String Crop_Type = rs.getString("Crop_Type");
//             String Fertilizer_1 = rs.getString("Fertilizer_1");
//                String Amount_F1 = rs.getString("Amount_F1");
//               String Fertilizer_2 = rs.getString("Fertilizer_2");
//               String Amount_F2 = rs.getString("Amount_F2");
//                String Fertilizer_3 = rs.getString("Fertilizer_3");
//               String Amount_F3 = rs.getString("Amount_F3");
//             list.add(new View(First_Name,Last_Name,NIC,Phone,Acrage,Crop_Type,Fertilizer_1,Amount_F1,Fertilizer_2,Amount_F2,Fertilizer_3,Amount_F3));
//            }
//       }
//       catch (SQLException e){
//           System.out.println(e.getMessage());
//       }
//        return list;
//   }
//}
