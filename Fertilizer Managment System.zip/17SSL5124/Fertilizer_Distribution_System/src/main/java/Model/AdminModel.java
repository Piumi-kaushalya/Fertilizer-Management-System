package Model;

import at.favre.lib.crypto.bcrypt.BCrypt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminModel {
    private static Connection connection = Db.getConn();
    private PreparedStatement stmt;
    private ResultSet rs;

    public static boolean BtnUser(String username, String password) {
        boolean result = false;
        String sql = "INSERT INTO user(User_name,password) VALUES (?,?)";
        try {
            PreparedStatement stat;
            stat = connection.prepareStatement(sql);
            //stat.setString(1,user_id);
            stat.setString(1,username);


            //stat.setString();
            stat.setString(2,password);
            result = stat.executeUpdate() == 1;
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }
        return result;

    }
//   public boolean isUniqueUser(String email) {
//        boolean result = false;
//        String sql = "SELECT COUNT(email) FROM user WHERE User_name = ?";
//        try {
//            stmt = connection.prepareStatement(sql);
//            stmt.setString(1, email);
//           ResultSet rs = stmt.executeQuery();
//           rs.next();
//            result = rs.getInt( 1) == 0;
//        } catch (SQLException e) {
//            System.out.println(e.getMessage());
//        }
//        return result;
//    }
    public boolean login(String username, String password){
        boolean result = false;
        String sql = "SELECT User_name,password FROM user WHERE User_name = ? LIMIT 1";
        try {
            stmt = connection.prepareStatement(sql);
            stmt.setString(1,username);
            //stmt.setString(2,password);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()){
                BCrypt.Result checkPwd = BCrypt.verifyer().verify(password.toCharArray(),rs.getString("password"));
                result = checkPwd.verified;
            }
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return result;
    }

}
