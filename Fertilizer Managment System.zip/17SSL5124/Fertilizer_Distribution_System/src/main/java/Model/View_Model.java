package Model;

import fertilizer_distribution_system.fertilizer_distribution_system.View;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class View_Model {
    private Connection conn = Db.getConn();
    private PreparedStatement stmt;
    private ResultSet rs;
    public static ObservableList<View> getUser(){
      Connection Conn = Db.getConn();
       ObservableList<View> list = FXCollections.observableArrayList();
       String sql = "SELECT * FROM farmers";
        try {
          PreparedStatement stmt;
        stmt = Conn.prepareStatement(sql);
       ResultSet rs = stmt.executeQuery();
          while (rs.next()){
              String First_Name = rs.getString("First_Name");
               String Last_Name = rs.getString("Last_Name");
                String NIC = rs.getString("NIC");
                String Phone = rs.getString("Phone");
               String Acrage = rs.getString("Acrage");
              String Crop_Type = rs.getString("Crop_Type");
             String Fertilizer_1 = rs.getString("Fertilizer_1");
                String Amount_F1 = rs.getString("Amount_F1");
               String Fertilizer_2 = rs.getString("Fertilizer_2");
               String Amount_F2 = rs.getString("Amount_F2");
                String Fertilizer_3 = rs.getString("Fertilizer_3");
              String Amount_F3 = rs.getString("Amount_F3");
             list.add(new View(First_Name,Last_Name,NIC,Phone,Acrage,Crop_Type,Fertilizer_1,Amount_F1,Fertilizer_2,Amount_F2,Fertilizer_3,Amount_F3));
            }
      }
       catch (SQLException e){
          System.out.println(e.getMessage());
      }
        return list;
   }
    public boolean delStudent(String NIC){
        Boolean result = false;
        String sql = "DELETE FROM farmers WHERE NIC = ? LIMIT 1";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, NIC);
            result =  stmt.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

}

