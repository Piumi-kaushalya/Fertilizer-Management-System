package Model;

import fertilizer_distribution_system.fertilizer_distribution_system.View;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdateModel {
    private Connection conn = Db.getConn();
    private PreparedStatement stmt;
    private ResultSet rs;

    public static ObservableList<View> getUpdate(){
        Connection Conn = Db.getConn();
        ObservableList<View> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM farmers";
        try {
            PreparedStatement stmt;
            stmt = Conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                String First_Name = rs.getString("First_Name");
                String Last_Name = rs.getString("Last_Name");
                String NIC = rs.getString("NIC");
                String Phone = rs.getString("Phone");
                String Acrage = rs.getString("Acrage");
                String Crop_Type = rs.getString("Crop_Type");
                String Fertilizer_1 = rs.getString("Fertilizer_1");
                String Amount_F1 = rs.getString("Amount_F1");
                String Fertilizer_2 = rs.getString("Fertilizer_2");
                String Amount_F2 = rs.getString("Amount_F2");
                String Fertilizer_3 = rs.getString("Fertilizer_3");
                String Amount_F3 = rs.getString("Amount_F3");
                list.add(new View(First_Name,Last_Name,NIC,Phone,Acrage,Crop_Type,Fertilizer_1,Amount_F1,Fertilizer_2,Amount_F2,Fertilizer_3,Amount_F3));
            }
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return list;
    }
    public boolean Updateuser(String first_Name, String last_Name, String NIC, String phone, String acrage, String crop_Type, String fertilizer_1, String amount_F1, String fertilizer_2, String amount_F2, String fertilizer_3, String amount_F3)

    {
        boolean result = false;
        PreparedStatement stmt;
        Connection con = Db.getConn();
        String sql = "update farmers set First_Name= '"+first_Name+"', Last_Name= '"+last_Name+"',NIC= '"+NIC+"',Phone= '"+phone+"',Acrage= '"+acrage+"',Crop_Type= '"+crop_Type+"',Fertilizer_1= '"+fertilizer_1+"',Amount_F1= '"+amount_F1+"',Fertilizer_2= '"+amount_F2+"',Fertilizer_3= '"+fertilizer_3+"',Amount_F3= '"+amount_F3+"' where NIC= '"+NIC+"'";

        //UPDATE `farmers` SET `First_Name`='[value-1]',`Last_Name`='[value-2]',`NIC`='[value-3]',`Phone`='[value-4]',`Acrage`='[value-5]',`Crop_Type`='[value-6]',`Fertilizer_1`='[value-7]',`Amount_F1`='[value-8]',`Fertilizer_2`='[value-9]',`Amount_F2`='[value-10]',`Fertilizer_3`='[value-11]',`Amount_F3`='[value-12]' WHERE 1
        //update students set id= '"+id+"', Name= '"+Name+"' where id='"+id+"'
        try {

            stmt = con.prepareStatement(sql);


            result = stmt.executeUpdate() == 1;

        } catch (SQLException e) {
            throw new RuntimeException(e);


        }
        return result;


    }
    public ResultSet getType1() {
        Connection con = Db.getConn();
        PreparedStatement stmt;
        ResultSet rs;

        String sql = "SELECT NIC FROM `farmers` ";
        try {
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rs;

    }


}
