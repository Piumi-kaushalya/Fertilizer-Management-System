module fertilizer_distribution_system.fertilizer_distribution_system {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires bcrypt;
    requires com.google.common;

    opens fertilizer_distribution_system.fertilizer_distribution_system to javafx.fxml;
    exports fertilizer_distribution_system.fertilizer_distribution_system;
   // exports fertilizer_distribution_system.fertilizer_distribution_system.Controller;
   // exports fertilizer_distribution_system.fertilizer_distribution_system;
    // opens fertilizer_distribution_system.fertilizer_distribution_system.Controller to javafx.fxml;
}